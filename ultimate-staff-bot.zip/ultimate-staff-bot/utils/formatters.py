def format_application_status(status: str) -> str:
    """Format application status for display"""
    status_map = {
        'pending': '⏳ Pending',
        'approved': '✅ Approved', 
        'denied': '❌ Denied',
        'review': '🔍 Under Review'
    }
    return status_map.get(status, status)