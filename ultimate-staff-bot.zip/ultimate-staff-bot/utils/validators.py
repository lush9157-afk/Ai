def is_valid_channel_id(channel_id: str) -> bool:
    """Validate if string is a valid channel ID"""
    try:
        return int(channel_id) > 0
    except:
        return False

def is_valid_role_id(role_id: str) -> bool:
    """Validate if string is a valid role ID"""
    try:
        return int(role_id) > 0
    except:
        return False