# Application constants
APPLICATION_CATEGORIES = ["Moderator", "Event Host", "Support Staff", "Trial Staff"]

# Status constants
STATUS_PENDING = "pending"
STATUS_APPROVED = "approved"
STATUS_DENIED = "denied"

# AI Constants
AI_SCORE_THRESHOLD = 85
AI_CONFIDENCE_HIGH = "HIGH"