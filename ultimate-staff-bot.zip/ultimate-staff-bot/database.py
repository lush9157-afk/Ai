import sqlite3
import json
import datetime
from typing import Dict, List, Any, Optional
import aiosqlite

class DatabaseManager:
    def __init__(self, db_path: str = 'staff_bot.db'):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Server configurations
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS server_configs (
                guild_id INTEGER PRIMARY KEY,
                config_data TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Applications system
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                username TEXT NOT NULL,
                category TEXT NOT NULL,
                current_roles TEXT,
                questions_asked TEXT,
                answers_given TEXT,
                ai_analysis TEXT,
                ai_score INTEGER,
                ai_recommendation TEXT,
                ai_strengths TEXT,
                ai_concerns TEXT,
                status TEXT DEFAULT 'pending',
                assigned_role TEXT,
                owner_approved BOOLEAN DEFAULT FALSE,
                auto_approved BOOLEAN DEFAULT FALSE,
                reviewed_by INTEGER,
                review_notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # User profiles
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_profiles (
                user_id INTEGER PRIMARY KEY,
                guild_id INTEGER NOT NULL,
                username TEXT NOT NULL,
                join_date TIMESTAMP,
                message_count INTEGER DEFAULT 0,
                warning_count INTEGER DEFAULT 0,
                application_count INTEGER DEFAULT 0,
                current_roles TEXT,
                performance_score INTEGER DEFAULT 0,
                last_active TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Server analytics
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS server_analytics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                date DATE NOT NULL,
                total_members INTEGER,
                members_joined INTEGER DEFAULT 0,
                members_left INTEGER DEFAULT 0,
                messages_sent INTEGER DEFAULT 0,
                active_members INTEGER DEFAULT 0,
                staff_actions INTEGER DEFAULT 0,
                applications_received INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Staff actions
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS staff_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                staff_id INTEGER NOT NULL,
                staff_name TEXT NOT NULL,
                action_type TEXT NOT NULL,
                target_id INTEGER,
                target_name TEXT,
                reason TEXT,
                duration INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    # Application methods
    def create_application(self, guild_id: int, user_id: int, username: str, category: str, questions: List[str], answers: List[str]) -> int:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO applications (guild_id, user_id, username, category, questions_asked, answers_given)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (guild_id, user_id, username, category, json.dumps(questions), json.dumps(answers)))
        
        app_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return app_id
    
    def update_application_analysis(self, app_id: int, analysis: Dict[str, Any]):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE applications SET 
            ai_analysis = ?, ai_score = ?, ai_recommendation = ?, 
            ai_strengths = ?, ai_concerns = ?, updated_at = ?
            WHERE id = ?
        ''', (
            json.dumps(analysis),
            analysis.get('overall_score'),
            analysis.get('recommendation'),
            json.dumps(analysis.get('strengths', [])),
            json.dumps(analysis.get('concerns', [])),
            datetime.datetime.now(),
            app_id
        ))
        
        conn.commit()
        conn.close()
    
    def get_pending_applications(self, guild_id: int) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM applications WHERE guild_id = ? AND status = "pending"', (guild_id,))
        applications = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return applications

# Global instance
db = DatabaseManager()