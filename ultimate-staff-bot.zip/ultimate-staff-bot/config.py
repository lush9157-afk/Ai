import os
import json
from dotenv import load_dotenv

load_dotenv()

class BotConfig:
    def __init__(self):
        self.token = os.getenv('DISCORD_BOT_TOKEN')
        self.settings = {
            'prefix': '!',
            'status': 'AI Staff Management',
            'activity_type': 'watching'
        }

class ServerConfig:
    def __init__(self, guild_id: int):
        self.guild_id = guild_id
        self.config_file = f'configs/server_{guild_id}.json'
        self.default_config = {
            'channels': {
                'staff_logs': None,
                'applications': None,
                'analytics': None,
                'staff_announcements': None
            },
            'roles': {
                'admin': None,
                'moderator': None,
                'staff': None,
                'trial_staff': None
            }
        }
        self.current_config = self.load_config()
    
    def load_config(self):
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return self.default_config
    
    def save_config(self):
        os.makedirs('configs', exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(self.current_config, f, indent=4)
    
    def update_channel(self, channel_type: str, channel_id: int):
        self.current_config['channels'][channel_type] = channel_id
        self.save_config()
    
    def update_role(self, role_type: str, role_id: int):
        self.current_config['roles'][role_type] = role_id
        self.save_config()

# Global instances
bot_config = BotConfig()