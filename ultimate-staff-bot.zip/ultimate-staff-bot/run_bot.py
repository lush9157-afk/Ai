#!/usr/bin/env python3
"""
Ultimate Staff Bot - Startup Script
"""

import os
import sys
import logging

def main():
    """Main startup function"""
    print("🚀 Starting Ultimate Staff Bot...")
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Check environment
    if not os.getenv('DISCORD_BOT_TOKEN'):
        print("❌ Missing DISCORD_BOT_TOKEN in environment")
        sys.exit(1)
    
    # Import and run bot
    try:
        from main import main as run_bot
        run_bot()
    except Exception as e:
        print(f"❌ Failed to start bot: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()