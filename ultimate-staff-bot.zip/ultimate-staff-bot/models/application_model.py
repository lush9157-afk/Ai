from dataclasses import dataclass
from typing import List, Dict, Any
import datetime

@dataclass
class Application:
    id: int
    guild_id: int
    user_id: int
    username: str
    category: str
    questions_asked: List[str]
    answers_given: List[str]
    ai_analysis: Dict[str, Any]
    status: str
    created_at: datetime.datetime