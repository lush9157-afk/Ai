from dataclasses import dataclass
import datetime

@dataclass
class UserProfile:
    user_id: int
    guild_id: int
    username: str
    join_date: datetime.datetime
    message_count: int
    warning_count: int
    application_count: int
    performance_score: int