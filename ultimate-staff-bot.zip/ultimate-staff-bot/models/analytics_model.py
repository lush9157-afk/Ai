from dataclasses import dataclass
import datetime

@dataclass
class Analytics:
    guild_id: int
    date: datetime.date
    total_members: int
    members_joined: int
    members_left: int
    messages_sent: int