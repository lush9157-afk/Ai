from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class ServerConfig:
    guild_id: int
    channels: Dict[str, Any]
    roles: Dict[str, Any]
    settings: Dict[str, Any]