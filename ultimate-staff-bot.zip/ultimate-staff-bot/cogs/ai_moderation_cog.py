import discord
from discord.ext import commands

class AIModerationCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.Cog.listener()
    async def on_message(self, message):
        """AI-powered message moderation"""
        if message.author.bot:
            return
        
        # AI analysis of message
        user_data = {
            'username': str(message.author),
            'join_date': message.author.joined_at.strftime("%Y-%m-%d") if message.author.joined_at else "Unknown"
        }
        
        moderation_result = await self.bot.ai.auto_moderate_message(message.content, user_data)
        
        if moderation_result.get('flag', False):
            # Take action based on severity
            severity = moderation_result.get('severity', 'LOW')
            
            if severity == 'HIGH':
                await message.delete()
                warning_msg = await message.channel.send(
                    f"{message.author.mention}, your message was removed for: {moderation_result.get('reason', 'Inappropriate content')}"
                )

async def setup(bot):
    await bot.add_cog(AIModerationCog(bot))