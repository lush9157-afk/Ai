import discord
from discord.ext import commands
from discord.ui import View, Button

class TicketSystemCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='ticket_setup')
    @commands.has_permissions(administrator=True)
    async def ticket_setup(self, ctx):
        """Setup ticket system"""
        embed = discord.Embed(
            title="🎫 Support Ticket System",
            description="Click the button below to create a support ticket!",
            color=discord.Color.blue()
        )
        view = TicketCreationView()
        await ctx.send(embed=embed, view=view)

class TicketCreationView(View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Create Ticket", style=discord.ButtonStyle.primary, emoji="🎫")
    async def create_ticket(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message("Ticket creation feature coming soon!", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TicketSystemCog(bot))