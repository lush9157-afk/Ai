import discord
from discord.ext import commands
import datetime

class AnalyticsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='analytics')
    @commands.has_permissions(manage_guild=True)
    async def show_analytics(self, ctx):
        """Show server analytics"""
        embed = discord.Embed(
            title="📊 Server Analytics",
            description="Server growth and activity statistics",
            color=discord.Color.blue(),
            timestamp=datetime.datetime.utcnow()
        )
        
        # Get analytics data from database
        monthly_data = self.bot.db.get_monthly_analytics(ctx.guild.id, 2024, 1)
        
        embed.add_field(name="Total Members", value=ctx.guild.member_count, inline=True)
        embed.add_field(name="Channels", value=len(ctx.guild.channels), inline=True)
        embed.add_field(name="Server Created", value=ctx.guild.created_at.strftime("%Y-%m-%d"), inline=True)
        
        if monthly_data:
            embed.add_field(name="Monthly Growth", value=monthly_data['totals']['net_growth'], inline=True)
            embed.add_field(name="Messages Sent", value=monthly_data['totals']['messages_sent'], inline=True)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AnalyticsCog(bot))