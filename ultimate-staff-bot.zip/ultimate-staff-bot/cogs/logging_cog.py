import discord
from discord.ext import commands
import datetime

class LoggingCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def log_member_join(self, member):
        """Log member join event"""
        config = self.get_server_config(member.guild.id)
        if config and config['channels']['staff_logs']:
            channel = self.bot.get_channel(config['channels']['staff_logs'])
            if channel:
                embed = discord.Embed(
                    title="Member Joined",
                    description=f"{member.mention} ({member.name})",
                    color=discord.Color.green(),
                    timestamp=datetime.datetime.utcnow()
                )
                await channel.send(embed=embed)
    
    async def log_member_leave(self, member):
        """Log member leave event"""
        config = self.get_server_config(member.guild.id)
        if config and config['channels']['staff_logs']:
            channel = self.bot.get_channel(config['channels']['staff_logs'])
            if channel:
                embed = discord.Embed(
                    title="Member Left",
                    description=f"{member.mention} ({member.name})",
                    color=discord.Color.red(),
                    timestamp=datetime.datetime.utcnow()
                )
                await channel.send(embed=embed)
    
    def get_server_config(self, guild_id):
        """Get server configuration"""
        # This would load from database or config file
        return {
            'channels': {
                'staff_logs': None,  # Would be actual channel ID
                'applications': None
            }
        }

async def setup(bot):
    await bot.add_cog(LoggingCog(bot))