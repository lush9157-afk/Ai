import discord
from discord.ext import commands
import json
import datetime

class BackupSystemCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='backup_config')
    @commands.has_permissions(administrator=True)
    async def backup_config(self, ctx):
        """Backup server configuration"""
        backup_data = {
            'guild_id': ctx.guild.id,
            'guild_name': ctx.guild.name,
            'backup_date': datetime.datetime.now().isoformat(),
            'channels': [{'id': c.id, 'name': c.name, 'type': str(c.type)} for c in ctx.guild.channels],
            'roles': [{'id': r.id, 'name': r.name} for r in ctx.guild.roles]
        }
        
        # Save backup
        filename = f"backups/{ctx.guild.id}_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(backup_data, f, indent=4)
        
        embed = discord.Embed(
            title="💾 Configuration Backed Up",
            description=f"Server configuration saved to `{filename}`",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(BackupSystemCog(bot))