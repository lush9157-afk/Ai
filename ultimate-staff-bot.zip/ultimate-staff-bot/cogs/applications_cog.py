import discord
from discord.ext import commands
from discord.ui import View, Button, Modal, TextInput, Select
import json

class ApplicationsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='application')
    async def start_application(self, ctx):
        """Start staff application"""
        embed = discord.Embed(
            title="🤖 AI Staff Application",
            description="Click below to start your application!",
            color=discord.Color.green()
        )
        view = ApplicationStartView(ctx)
        await ctx.send(embed=embed, view=view)

class ApplicationStartView(View):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
    
    @discord.ui.select(
        placeholder="Choose staff role...",
        options=[
            discord.SelectOption(label="Moderator", emoji="🛡️"),
            discord.SelectOption(label="Event Host", emoji="🎉"),
            discord.SelectOption(label="Support Staff", emoji="🤝")
        ]
    )
    async def role_select(self, interaction: discord.Interaction, select: Select):
        user_data = {
            'username': str(interaction.user),
            'join_date': interaction.user.joined_at.strftime("%Y-%m-%d")
        }
        questions = await self.ctx.bot.ai.generate_dynamic_questions(user_data, select.values[0])
        modal = AIApplicationModal(questions, select.values[0], self.ctx)
        await interaction.response.send_modal(modal)

class AIApplicationModal(Modal):
    def __init__(self, questions, role, ctx):
        super().__init__(title=f"Application - {role}")
        self.questions = questions
        self.role = role
        self.ctx = ctx
        
        for i, question in enumerate(questions[:5]):
            self.add_item(TextInput(
                label=f"Q{i+1}",
                placeholder=question[:100],
                style=discord.TextStyle.paragraph,
                required=True
            ))
    
    async def on_submit(self, interaction: discord.Interaction):
        answers = {self.questions[i]: child.value for i, child in enumerate(self.children)}
        
        application_data = {
            'username': str(interaction.user),
            'category': self.role,
            'qa_pairs': answers
        }
        
        # Save to database
        app_id = self.ctx.bot.db.create_application(
            interaction.guild.id,
            interaction.user.id,
            str(interaction.user),
            self.role,
            self.questions,
            list(answers.values())
        )
        
        # AI Analysis
        analysis = await self.ctx.bot.ai.comprehensive_application_analysis(application_data)
        self.ctx.bot.db.update_application_analysis(app_id, analysis)
        
        await interaction.response.send_message("✅ Application submitted! AI is analyzing your responses.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ApplicationsCog(bot))