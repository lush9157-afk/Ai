import discord
from discord.ext import commands
from discord.ui import View, Button, Modal, TextInput
from config import ServerConfig

class SetupCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='setup')
    @commands.has_permissions(administrator=True)
    async def setup(self, ctx):
        """Start setup wizard"""
        embed = discord.Embed(
            title="🚀 Ultimate Staff Bot Setup",
            description="Let's configure your server!",
            color=discord.Color.blue()
        )
        view = SetupStartView(ctx)
        await ctx.send(embed=embed, view=view)

class SetupStartView(View):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
    
    @discord.ui.button(label="Start Setup", style=discord.ButtonStyle.primary, emoji="⚙️")
    async def start_setup(self, interaction: discord.Interaction, button: Button):
        modal = ChannelSetupModal(self.ctx)
        await interaction.response.send_modal(modal)

class ChannelSetupModal(Modal, title="Channel Configuration"):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.staff_logs = TextInput(label="Staff Logs Channel ID", placeholder="123456789", required=True)
        self.applications = TextInput(label="Applications Channel ID", placeholder="123456789", required=True)
        self.analytics = TextInput(label="Analytics Channel ID", placeholder="123456789", required=True)
        
        self.add_item(self.staff_logs)
        self.add_item(self.applications)
        self.add_item(self.analytics)
    
    async def on_submit(self, interaction: discord.Interaction):
        server_config = ServerConfig(interaction.guild.id)
        server_config.update_channel('staff_logs', int(self.staff_logs.value))
        server_config.update_channel('applications', int(self.applications.value))
        server_config.update_channel('analytics', int(self.analytics.value))
        
        await interaction.response.send_message("✅ Channels configured! Use `!setup_roles` for role setup.")

async def setup(bot):
    await bot.add_cog(SetupCog(bot))