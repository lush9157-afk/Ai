import discord
from discord.ui import View, Button

class SetupCompleteView(View):
    def __init__(self):
        super().__init__(timeout=300)
    
    @discord.ui.button(label="Finish Setup", style=discord.ButtonStyle.success, emoji="🎉")
    async def finish(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message("Setup completed successfully!", ephemeral=True)