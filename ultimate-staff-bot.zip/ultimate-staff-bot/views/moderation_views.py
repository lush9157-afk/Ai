import discord
from discord.ui import View, Button

class ModerationActionsView(View):
    def __init__(self, target_id):
        super().__init__(timeout=300)
        self.target_id = target_id
    
    @discord.ui.button(label="Warn", style=discord.ButtonStyle.secondary, emoji="⚠️")
    async def warn(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message(f"Warning user {self.target_id}", ephemeral=True)