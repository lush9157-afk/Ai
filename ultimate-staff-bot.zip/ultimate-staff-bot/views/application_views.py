import discord
from discord.ui import View, Button, Select, Modal, TextInput

class ApplicationReviewView(View):
    def __init__(self, app_id, applicant_id):
        super().__init__(timeout=None)
        self.app_id = app_id
        self.applicant_id = applicant_id
    
    @discord.ui.button(label="Approve", style=discord.ButtonStyle.success, emoji="✅")
    async def approve(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message(f"Application {self.app_id} approved!", ephemeral=True)
    
    @discord.ui.button(label="Deny", style=discord.ButtonStyle.danger, emoji="❌")
    async def deny(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message(f"Application {self.app_id} denied!", ephemeral=True)