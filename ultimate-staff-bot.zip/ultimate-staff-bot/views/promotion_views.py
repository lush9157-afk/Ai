import discord
from discord.ui import View, Button

class PromotionAssessmentView(View):
    def __init__(self, user_id):
        super().__init__(timeout=300)
        self.user_id = user_id
    
    @discord.ui.button(label="Start Assessment", style=discord.ButtonStyle.primary, emoji="🎯")
    async def start_assessment(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message("Starting promotion assessment...", ephemeral=True)