import google.generativeai as genai
import openai
import os
import json
import asyncio
from typing import Dict, List, Any

class AdvancedAIProcessor:
    def __init__(self):
        self.gemini_api_key = os.getenv('GEMINI_API_KEY')
        self.openai_api_key = os.getenv('OPENAI_API_KEY')
        
        if self.gemini_api_key:
            genai.configure(api_key=self.gemini_api_key)
            self.gemini_model = genai.GenerativeModel('gemini-pro')
        
        if self.openai_api_key:
            self.openai_client = openai.AsyncOpenAI(api_key=self.openai_api_key)
    
    async def generate_dynamic_questions(self, user_data: Dict, category: str, stage: str = "initial") -> List[str]:
        prompt = f"""
        Generate staff application questions for {category} role.
        User: {user_data.get('username')}
        Stage: {stage}
        Return JSON array of questions.
        """
        
        try:
            if hasattr(self, 'gemini_model'):
                response = await asyncio.to_thread(self.gemini_model.generate_content, prompt)
                return json.loads(response.text)
        except:
            pass
        
        return [
            f"Why do you want to be a {category}?",
            "What experience do you have?",
            "How active are you?",
            "How would you handle a difficult situation?",
            "What makes you a good candidate?"
        ]
    
    async def comprehensive_application_analysis(self, application_data: Dict) -> Dict[str, Any]:
        analysis_prompt = f"""
        Analyze staff application for {application_data['category']}.
        Answers: {json.dumps(application_data['qa_pairs'])}
        Return JSON with: overall_score, recommendation, strengths, concerns
        """
        
        try:
            if hasattr(self, 'openai_client'):
                response = await self.openai_client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": analysis_prompt}],
                    response_format={"type": "json_object"}
                )
                return json.loads(response.choices[0].message.content)
        except:
            pass
        
        return {
            "overall_score": 50,
            "recommendation": "REVIEW",
            "strengths": ["Application submitted"],
            "concerns": ["Needs manual review"],
            "auto_approval_recommended": False
        }

# Global instance
ai_processor = AdvancedAIProcessor()