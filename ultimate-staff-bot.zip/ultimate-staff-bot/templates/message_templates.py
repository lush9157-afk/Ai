def welcome_message(guild_name: str) -> str:
    """Welcome message template"""
    return f"Welcome to {guild_name}! Use `!application` to apply for staff."

def application_submitted_message() -> str:
    """Application submitted message"""
    return "✅ Your application has been submitted! Staff will review it soon."