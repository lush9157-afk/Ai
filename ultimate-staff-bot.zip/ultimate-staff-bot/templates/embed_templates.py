import discord

def create_success_embed(title: str, description: str) -> discord.Embed:
    """Create success embed"""
    return discord.Embed(
        title=title,
        description=description,
        color=discord.Color.green()
    )

def create_error_embed(title: str, description: str) -> discord.Embed:
    """Create error embed"""
    return discord.Embed(
        title=title,
        description=description,
        color=discord.Color.red()
    )