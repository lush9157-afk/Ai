import discord

def create_application_embed(application_data):
    """Create embed for application display"""
    embed = discord.Embed(
        title=f"📝 Staff Application - {application_data['category']}",
        description=f"Applicant: {application_data['username']}",
        color=discord.Color.blue()
    )
    return embed