import discord
from discord.ext import commands, tasks
import asyncio
import datetime
import logging
from typing import Optional

from config import bot_config, ServerConfig
from database import db
from ai_processor import ai_processor

# Import cogs
from cogs.setup_cog import SetupCog
from cogs.applications_cog import ApplicationsCog
from cogs.logging_cog import LoggingCog
from cogs.analytics_cog import AnalyticsCog
from cogs.moderation_cog import ModerationCog
from cogs.ai_moderation_cog import AIModerationCog
from cogs.auto_promotions_cog import AutoPromotionsCog
from cogs.ticket_system import TicketSystemCog
from cogs.backup_system import BackupSystemCog

class UltimateStaffBot(commands.Bot):
    """Ultimate Staff Management Bot with AI Integration"""
    
    def __init__(self):
        intents = discord.Intents.all()
        
        super().__init__(
            command_prefix=bot_config.settings['prefix'],
            intents=intents,
            help_command=None,
            case_insensitive=True
        )
        
        self.config = bot_config
        self.db = db
        self.ai = ai_processor
        
        # Bot startup time
        self.startup_time = datetime.datetime.now()
        
        # Load cogs
        self.initial_extensions = [
            'cogs.setup_cog',
            'cogs.applications_cog', 
            'cogs.logging_cog',
            'cogs.analytics_cog',
            'cogs.moderation_cog',
            'cogs.ai_moderation_cog',
            'cogs.auto_promotions_cog',
            'cogs.ticket_system',
            'cogs.backup_system'
        ]
    
    async def setup_hook(self):
        """Called when bot is starting"""
        print("🚀 Starting Ultimate Staff Bot...")
        
        # Load all cogs
        for extension in self.initial_extensions:
            try:
                await self.load_extension(extension)
                print(f"✅ Loaded: {extension}")
            except Exception as e:
                print(f"❌ Failed to load {extension}: {e}")
        
        # Sync application commands
        await self.tree.sync()
        print("✅ Application commands synced!")
        
        # Start background tasks
        self.background_tasks.start()
        print("✅ Background tasks started!")
    
    @tasks.loop(minutes=5)
    async def background_tasks(self):
        """Run background maintenance tasks"""
        try:
            # Update bot status
            await self.update_bot_status()
            
            # Check for pending tasks
            await self.process_pending_tasks()
            
        except Exception as e:
            print(f"Background task error: {e}")
    
    async def update_bot_status(self):
        """Update bot presence status"""
        total_servers = len(self.guilds)
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name=f"AI Staff Management | {total_servers} servers"
        )
        await self.change_presence(activity=activity)
    
    async def process_pending_tasks(self):
        """Process various pending tasks"""
        # This would handle things like:
        # - Expired temporary bans
        # - Pending application reminders
        # - Analytics data collection
        # - Backup rotations
        pass
    
    async def on_ready(self):
        """Called when bot is ready"""
        print(f"\n🎉 {self.user} is now online!")
        print(f"📊 Connected to {len(self.guilds)} servers")
        print(f"🕒 Startup time: {self.startup_time}")
        print(f"🔧 Prefix: {self.config.settings['prefix']}")
        print("=" * 50)
    
    async def on_guild_join(self, guild):
        """Called when bot joins a new server"""
        print(f"➕ Joined new server: {guild.name} (ID: {guild.id})")
        
        # Send welcome message
        embed = discord.Embed(
            title="🎉 Ultimate Staff Bot - Setup Required",
            description="Thank you for adding me to your server!",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="Quick Setup",
            value="Use `!setup` to configure the bot for your server",
            inline=False
        )
        
        embed.add_field(
            name="Features", 
            value="• AI-Powered Staff Applications\n• Advanced Moderation\n• Analytics & Insights\n• Auto Promotions\n• Ticket System",
            inline=False
        )
        
        # Try to send to system channel or first text channel
        try:
            if guild.system_channel:
                await guild.system_channel.send(embed=embed)
            else:
                for channel in guild.text_channels:
                    if channel.permissions_for(guild.me).send_messages:
                        await channel.send(embed=embed)
                        break
        except Exception as e:
            print(f"Could not send welcome message to {guild.name}: {e}")
    
    async def on_guild_remove(self, guild):
        """Called when bot is removed from a server"""
        print(f"➖ Removed from server: {guild.name} (ID: {guild.id})")
    
    async def on_member_join(self, member):
        """Called when a member joins the server"""
        # Update analytics
        guild_id = member.guild.id
        today = datetime.date.today().isoformat()
        
        # Record join in analytics
        self.db.record_daily_analytics(guild_id, today, {
            'members_joined': 1,
            'total_members': member.guild.member_count
        })
        
        # Log join event
        logging_cog = self.get_cog('LoggingCog')
        if logging_cog:
            await logging_cog.log_member_join(member)
    
    async def on_member_remove(self, member):
        """Called when a member leaves the server"""
        # Update analytics
        guild_id = member.guild.id
        today = datetime.date.today().isoformat()
        
        self.db.record_daily_analytics(guild_id, today, {
            'members_left': 1,
            'total_members': member.guild.member_count
        })
        
        # Log leave event
        logging_cog = self.get_cog('LoggingCog')
        if logging_cog:
            await logging_cog.log_member_leave(member)
    
    async def on_command_error(self, ctx, error):
        """Global command error handler"""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore command not found errors
        
        elif isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                title="❌ Permission Denied",
                description="You don't have permission to use this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
        
        elif isinstance(error, commands.BotMissingPermissions):
            embed = discord.Embed(
                title="❌ Bot Missing Permissions",
                description="I need additional permissions to execute this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
        
        elif isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(
                title="❌ Missing Argument",
                description=f"Missing required argument: `{error.param.name}`",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
        
        else:
            # Log unexpected errors
            print(f"Unexpected error in command {ctx.command}: {error}")
            
            embed = discord.Embed(
                title="❌ Unexpected Error",
                description="An unexpected error occurred. Please try again later.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    @commands.command(name='ping')
    async def ping(self, ctx):
        """Check bot latency"""
        latency = round(self.latency * 1000)
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"Bot latency: `{latency}ms`",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name='botinfo')
    async def bot_info(self, ctx):
        """Display bot information"""
        embed = discord.Embed(
            title="🤖 Ultimate Staff Bot Information",
            color=discord.Color.blue(),
            timestamp=datetime.datetime.utcnow()
        )
        
        embed.add_field(name="Servers", value=len(self.guilds), inline=True)
        embed.add_field(name="Latency", value=f"{round(self.latency * 1000)}ms", inline=True)
        embed.add_field(name="Uptime", value=self.get_uptime(), inline=True)
        embed.add_field(name="Python Version", value=sys.version.split()[0], inline=True)
        embed.add_field(name="discord.py Version", value=discord.__version__, inline=True)
        embed.add_field(name="Source Code", value="[GitHub](https://github.com/your-repo)", inline=True)
        
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=embed)

    def get_uptime(self):
        """Calculate bot uptime"""
        delta = datetime.datetime.now() - self.startup_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        
        if days > 0:
            return f"{days}d {hours}h {minutes}m {seconds}s"
        elif hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        else:
            return f"{minutes}m {seconds}s"

# Create and run bot instance
def main():
    """Main function to run the bot"""
    bot = UltimateStaffBot()
    
    try:
        bot.run(bot_config.token)
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user")
    except Exception as e:
        print(f"❌ Failed to start bot: {e}")

if __name__ == "__main__":
    main()